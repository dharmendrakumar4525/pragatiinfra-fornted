export const GET_SITE_API ="/createsite";
export const PURCHASE_REQUEST_API ="/purchaserequest";
