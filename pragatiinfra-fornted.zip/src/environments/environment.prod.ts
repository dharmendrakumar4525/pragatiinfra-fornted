export const environment = {
  production: true,
  app_name:"pragatiinfra",
  encryption: false,
  environmentType:'local',
  api_path: 'https://pr.avidusinteractive.com/api',
  cookiesOptions: {
    storeUnencoded: true,
    sameSite: 'Strict',
    secure: true,
    expires:new Date()
  },
  request_encode_key: '@#$Gg4sdVVJuY5443g]&$#TVS@#f3g2&^%JH#2fc2@^%f2f23f#@@#fg',
  private_key: '1JuYo2]&2%^%f2f23f#'
};