import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orgmaster',
  templateUrl: './orgmaster.component.html',
  styleUrls: ['./orgmaster.component.css']
})
export class OrgmasterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
