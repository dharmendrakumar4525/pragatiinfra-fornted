import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reject-reason',
  templateUrl: './reject-reason.component.html',
  styleUrls: ['./reject-reason.component.css']
})
export class RejectReasonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
