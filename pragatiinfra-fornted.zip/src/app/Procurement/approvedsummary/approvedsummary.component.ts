import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approvedsummary',
  templateUrl: './approvedsummary.component.html',
  styleUrls: ['./approvedsummary.component.css']
})
export class ApprovedsummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
