import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-revisedpurchasereqlist',
  templateUrl: './revisedpurchasereqlist.component.html',
  styleUrls: ['./revisedpurchasereqlist.component.css']
})
export class RevisedpurchasereqlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
