import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pendingpo',
  templateUrl: './pendingpo.component.html',
  styleUrls: ['./pendingpo.component.css']
})
export class PendingpoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
