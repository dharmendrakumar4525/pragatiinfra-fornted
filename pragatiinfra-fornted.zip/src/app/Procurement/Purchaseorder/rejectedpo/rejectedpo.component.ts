import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rejectedpo',
  templateUrl: './rejectedpo.component.html',
  styleUrls: ['./rejectedpo.component.css']
})
export class RejectedpoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
