import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pomcreator',
  templateUrl: './pomcreator.component.html',
  styleUrls: ['./pomcreator.component.css']
})
export class PomcreatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
