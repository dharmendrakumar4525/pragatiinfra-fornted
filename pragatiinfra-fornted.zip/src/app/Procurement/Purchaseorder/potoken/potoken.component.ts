import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-potoken',
  templateUrl: './potoken.component.html',
  styleUrls: ['./potoken.component.css']
})
export class PotokenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
