import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rejectedpom',
  templateUrl: './rejectedpom.component.html',
  styleUrls: ['./rejectedpom.component.css']
})
export class RejectedpomComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
