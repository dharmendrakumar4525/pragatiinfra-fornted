import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apo-vendorpostatus',
  templateUrl: './apo-vendorpostatus.component.html',
  styleUrls: ['./apo-vendorpostatus.component.css']
})
export class ApoVendorpostatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
