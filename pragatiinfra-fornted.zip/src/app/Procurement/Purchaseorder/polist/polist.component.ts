import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-polist',
  templateUrl: './polist.component.html',
  styleUrls: ['./polist.component.css']
})
export class PolistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
