import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pomapprover',
  templateUrl: './pomapprover.component.html',
  styleUrls: ['./pomapprover.component.css']
})
export class PomapproverComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
