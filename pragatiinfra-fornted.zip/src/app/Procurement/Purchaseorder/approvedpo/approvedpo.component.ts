import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approvedpo',
  templateUrl: './approvedpo.component.html',
  styleUrls: ['./approvedpo.component.css']
})
export class ApprovedpoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
