import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pomcreator-esign',
  templateUrl: './pomcreator-esign.component.html',
  styleUrls: ['./pomcreator-esign.component.css']
})
export class PomcreatorEsignComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
