import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rejectedpurchaserequest',
  templateUrl: './rejectedpurchaserequest.component.html',
  styleUrls: ['./rejectedpurchaserequest.component.css']
})
export class RejectedpurchaserequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
