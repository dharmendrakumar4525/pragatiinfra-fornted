import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categorymanagement',
  templateUrl: './categorymanagement.component.html',
  styleUrls: ['./categorymanagement.component.css']
})
export class CategorymanagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
