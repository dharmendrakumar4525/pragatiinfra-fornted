import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approvedmaterialrequest',
  templateUrl: './approvedmaterialrequest.component.html',
  styleUrls: ['./approvedmaterialrequest.component.css']
})
export class ApprovedmaterialrequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
