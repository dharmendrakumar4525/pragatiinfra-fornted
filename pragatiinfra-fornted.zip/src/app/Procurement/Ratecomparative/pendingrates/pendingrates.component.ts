import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pendingrates',
  templateUrl: './pendingrates.component.html',
  styleUrls: ['./pendingrates.component.css']
})
export class PendingratesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
