import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rateapprovalsummary',
  templateUrl: './rateapprovalsummary.component.html',
  styleUrls: ['./rateapprovalsummary.component.css']
})
export class RateapprovalsummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
