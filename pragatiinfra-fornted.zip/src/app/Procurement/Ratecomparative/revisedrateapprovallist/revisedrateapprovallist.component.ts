import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-revisedrateapprovallist',
  templateUrl: './revisedrateapprovallist.component.html',
  styleUrls: ['./revisedrateapprovallist.component.css']
})
export class RevisedrateapprovallistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
