import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rateapprovallist',
  templateUrl: './rateapprovallist.component.html',
  styleUrls: ['./rateapprovallist.component.css']
})
export class RateapprovallistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
