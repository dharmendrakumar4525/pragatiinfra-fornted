import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rejectedratessummary',
  templateUrl: './rejectedratessummary.component.html',
  styleUrls: ['./rejectedratessummary.component.css']
})
export class RejectedratessummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
