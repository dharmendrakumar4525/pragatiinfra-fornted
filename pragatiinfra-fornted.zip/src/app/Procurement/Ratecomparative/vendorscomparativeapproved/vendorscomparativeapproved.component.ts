import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendorscomparativeapproved',
  templateUrl: './vendorscomparativeapproved.component.html',
  styleUrls: ['./vendorscomparativeapproved.component.css']
})
export class VendorscomparativeapprovedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
