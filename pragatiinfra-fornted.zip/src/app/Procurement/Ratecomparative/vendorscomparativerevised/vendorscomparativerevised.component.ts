import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendorscomparativerevised',
  templateUrl: './vendorscomparativerevised.component.html',
  styleUrls: ['./vendorscomparativerevised.component.css']
})
export class VendorscomparativerevisedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
