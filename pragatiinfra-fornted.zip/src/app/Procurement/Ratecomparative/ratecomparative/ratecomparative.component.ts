import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ratecomparative',
  templateUrl: './ratecomparative.component.html',
  styleUrls: ['./ratecomparative.component.css']
})
export class RatecomparativeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
