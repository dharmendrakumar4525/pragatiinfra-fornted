import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendorscomparativerejected',
  templateUrl: './vendorscomparativerejected.component.html',
  styleUrls: ['./vendorscomparativerejected.component.css']
})
export class VendorscomparativerejectedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
