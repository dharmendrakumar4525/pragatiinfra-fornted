import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rejectedsummary',
  templateUrl: './rejectedsummary.component.html',
  styleUrls: ['./rejectedsummary.component.css']
})
export class RejectedsummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
