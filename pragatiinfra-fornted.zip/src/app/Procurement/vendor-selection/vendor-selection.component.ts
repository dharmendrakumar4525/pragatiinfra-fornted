import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-selection',
  templateUrl: './vendor-selection.component.html',
  styleUrls: ['./vendor-selection.component.css']
})
export class VendorSelectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
