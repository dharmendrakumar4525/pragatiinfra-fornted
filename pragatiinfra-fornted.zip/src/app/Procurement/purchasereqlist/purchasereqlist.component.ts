import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchasereqlist',
  templateUrl: './purchasereqlist.component.html',
  styleUrls: ['./purchasereqlist.component.css']
})
export class PurchasereqlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
