import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pendingpurchaserequest',
  templateUrl: './pendingpurchaserequest.component.html',
  styleUrls: ['./pendingpurchaserequest.component.css']
})
export class PendingpurchaserequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
