import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pendingsummary',
  templateUrl: './pendingsummary.component.html',
  styleUrls: ['./pendingsummary.component.css']
})
export class PendingsummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
