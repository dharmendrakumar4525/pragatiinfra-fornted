import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-itemmaster',
  templateUrl: './itemmaster.component.html',
  styleUrls: ['./itemmaster.component.css']
})
export class ItemmasterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
