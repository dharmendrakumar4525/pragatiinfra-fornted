import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendormaster',
  templateUrl: './vendormaster.component.html',
  styleUrls: ['./vendormaster.component.css']
})
export class VendormasterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
