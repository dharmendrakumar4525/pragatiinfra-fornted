import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requisitionapprovals',
  templateUrl: './requisitionapprovals.component.html',
  styleUrls: ['./requisitionapprovals.component.css']
})
export class RequisitionapprovalsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
