import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { PurchaseRequestComponent } from './purchase-request/purchase-request.component';
import { PurchaseRequestDetailsComponent } from './purchase-request-details/purchase-request-details.component';


const routes: Routes = [
  {
    path: "",
    component: PurchaseRequestComponent
  },
  {
    path: "/:id",
    component: PurchaseRequestDetailsComponent
  },
];


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    [RouterModule.forChild(routes)],
  ]
})
export class ProcurmentModuleModule { }
