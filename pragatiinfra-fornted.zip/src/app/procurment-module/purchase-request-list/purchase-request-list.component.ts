import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-request-list',
  templateUrl: './purchase-request-list.component.html',
  styleUrls: ['./purchase-request-list.component.css']
})
export class PurchaseRequestListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
