import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-revise-purchase-request',
  templateUrl: './revise-purchase-request.component.html',
  styleUrls: ['./revise-purchase-request.component.css']
})
export class RevisePurchaseRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
