export enum SidePanelPosition {
  LEFT = 'panel-position-left',
  RIGHT = 'panel-position-right'
}