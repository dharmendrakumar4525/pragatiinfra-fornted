import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-master-createuser',
  templateUrl: './master-createuser.component.html',
  styleUrls: ['./master-createuser.component.css']
})
export class MasterCreateuserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
