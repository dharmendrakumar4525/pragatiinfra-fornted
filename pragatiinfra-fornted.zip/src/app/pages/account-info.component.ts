import { Component, Input } from '@angular/core';

@Component({
  selector: 'Account Info',
  template: `<div style="padding: 1.5rem;"><h1>Account Info</h1></div>`,
  styles: [`h1 { font-family: 'Poppins', sans-serif !important;  }`]
})
export class AccountInfoComponent  {
}
