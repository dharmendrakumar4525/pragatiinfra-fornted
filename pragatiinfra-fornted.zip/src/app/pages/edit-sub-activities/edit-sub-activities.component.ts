import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-sub-activities',
  templateUrl: './edit-sub-activities.component.html',
  styleUrls: ['./edit-sub-activities.component.css']
})
export class EditSubActivitiesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
